import boto3
import time
import calendar
import json
import urllib.parse
import calendar
import time

def get_adobe_topic(sns):
    # list_topics() has a limit of 100 per poll, so may need to create a waiter if there are >100 SNS Topics

    topics = sns.meta.client.list_topics()
    for topic in topics["Topics"]:
        arn = topic["TopicArn"]
        t = sns.Topic(arn)
        if t.attributes["DisplayName"] == "AdobeDevopsExerciseTopic":
            return arn

def is_text(content):
    try:
        content.decode()
        return True
    except:
        return False
    return None

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if abs(o) % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)

def lambda_function(event, context):
    s3 = boto3.resource("s3")
    sns = boto3.resource("sns")
    dynamodb = boto3.resource("dynamodb")
    
    ####################################################################
    # This is our S3 section
    ####################################################################
    
    message = []
    # print("event:\n{}".format(json.dumps(event, indent=4)))
    bucket_name = event["Records"][0]["s3"]["bucket"]["name"]
    key = urllib.parse.unquote_plus(event["Records"][0]["s3"]["object"]["key"])
    print("Key: {}".format(key))

    obj = s3.Object(bucket_name, key)

    content = obj.get()["Body"].read()
    lines = -1
    if is_text(content):
        lines = len(content.decode().split("\n"))

    ####################################################################
    # Gather our information
    ####################################################################
    # bucket name = bucket_name
    filename = key
    filesize = obj.content_length
    filelines = lines if is_text(content) else "(binary file)"
    fileepoch = calendar.timegm(time.gmtime())

    ####################################################################
    # This is our SNS section
    ####################################################################
    
    message = []
    message.append("A file has been uploaded to Amazon S3.")
    message.append("Bucket: {}".format(bucket_name))
    message.append("Filename: {}".format(filename))
    message.append("Lines: {}".format(filelines))
    message.append("Epoch: {}".format(fileepoch))
    
    message_joined = "\n".join(message)
    
    topic = sns.Topic(get_adobe_topic(sns))
    topic.publish(Message=message_joined, Subject="New file upload to {}".format(bucket_name))

    ####################################################################
    # This is our DynamoDB section
    ####################################################################
    
    item = {
        "Filename": key,
        "Bucket": bucket_name,
        "Lines": lines,
        "Size": obj.content_length
    }
    item2 = {
        "Filename": { "S": key },
        "Bucket": { "S": bucket_name },
        "Lines": { "N": lines} ,
        "Size": { "N": obj.content_length }
    }
    table = dynamodb.Table("Files")
    results = table.put_item(
        Item=item
    )


